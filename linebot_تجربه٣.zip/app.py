from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage, JoinEvent

import os
from dotenv import load_dotenv

# تحميل القيم من .env
load_dotenv()
CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN")
CHANNEL_SECRET = os.getenv("LINE_CHANNEL_SECRET")

app = Flask(__name__)
line_bot_api = LineBotApi(CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(CHANNEL_SECRET)

# قائمة الأدمن
ADMINS = ["Ub0345b01633bbe470bb6ca45ed48a913"]

# الحالة: قفل أو فتح القروب
group_locked = {}

@app.route("/api/webhook", methods=['POST'])
def callback():
    signature = request.headers['X-Line-Signature']
    body = request.get_data(as_text=True)

    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)

    return 'OK'

# عند دخول البوت القروب
@handler.add(JoinEvent)
def handle_join(event):
    line_bot_api.reply_message(
        event.reply_token,
        TextSendMessage(text="✅ بوت الحماية مفعل في هذا القروب")
    )

# عند استقبال رسالة
@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    user_id = event.source.user_id
    text = event.message.text
    reply_token = event.reply_token
    source_type = event.source.type

    # تحقق إذا المستخدم أدمن
    is_admin = user_id in ADMINS

    # إذا الرسالة داخل قروب
    if source_type == "group":
        group_id = event.source.group_id

        # قفل القروب
        if text == "قفل القروب" and is_admin:
            group_locked[group_id] = True
            line_bot_api.reply_message(reply_token, TextSendMessage(text="🔒 تم قفل القروب"))

        # فتح القروب
        elif text == "فتح القروب" and is_admin:
            group_locked[group_id] = False
            line_bot_api.reply_message(reply_token, TextSendMessage(text="🔓 تم فتح القروب"))

        # طرد عضو (مبدئيًا رد فقط)
        elif text.startswith("طرد") and is_admin:
            line_bot_api.reply_message(reply_token, TextSendMessage(text="🚫 تم طرد العضو (ميزة الطرد قريبًا)"))

        # عرض الأدمن
        elif text == "الادمن":
            admins_list = "\n".join(ADMINS)
            line_bot_api.reply_message(reply_token, TextSendMessage(text=f"👮 قائمة الأدمن:\n{admins_list}"))

        # منع الرسائل إذا القروب مقفل
        elif group_locked.get(group_id, False) and not is_admin:
            return

        else:
            line_bot_api.reply_message(reply_token, TextSendMessage(text=f"📩 {text}"))

    else:
        line_bot_api.reply_message(reply_token, TextSendMessage(text=f"🤖 استقبلت رسالتك: {text}"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
